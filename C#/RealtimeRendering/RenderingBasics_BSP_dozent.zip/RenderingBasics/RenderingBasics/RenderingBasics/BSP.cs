﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace RenderingBasics
{
    public class BSP
    {
        // the largest bsp node
        private BSPNode root;
        /// <summary> c-tor
        /// </summary>
        public BSP(Vector3 min, Vector3 max)
        {
            this.root = new BSPNode(min, max);
        }
        /// <summary> add an object to the bsp tree
        /// </summary>
        public void AddObject(GraphicsEntity ent)
        {
            if (!this.root.AddObject(ent, 5))
            {
                throw new Exception("BSP too small for world!");
            }
        }

        public List<GraphicsEntity> FindObjects(BoundingBox area)
        {
            List<GraphicsEntity> outObjects = new List<GraphicsEntity>();
            this.root.FindObjects(area, ref outObjects);
            return outObjects;
        }
    }

    public class BSPNode
    {
        // container for graphics entities
        private List<GraphicsEntity> contents = new List<GraphicsEntity>();
        // the 8 child nodes of this bsp node
        private BSPNode[] childNodes;
        // the bounding box of this node
        private BoundingBox aabb;

        /// <summary> c-tor
        /// </summary>
        public BSPNode(Vector3 min, Vector3 max)
        {
            this.aabb = new BoundingBox(min, max);
        }

        /// <summary> Create the child nodes
        /// </summary>
        private void InitChildren()
        {
            if (null != this.childNodes)
            {
                return;
            }

            Vector3 center = (this.aabb.Min + this.aabb.Max) * 0.5f;
            this.childNodes = new BSPNode[8];

            Vector3[] corners = this.aabb.GetCorners();
            for (int i=0; i<8; ++i)
            {
                this.childNodes[i] = new BSPNode(corners[i], center);
            }
        }

        /// <summary>returns true if the object is completely contained in this node
        /// </summary>
        internal bool AddObject(GraphicsEntity ent, int maxSublevels)
        {
            if (maxSublevels < 0)
            {
                return false;
            }

            // check if ent lies completely within this nodes area
            if (this.aabb.Contains(ent.Aabb) == ContainmentType.Contains)
            {
                this.InitChildren();
                // if it does, check the next layer
                foreach (BSPNode childNode in this.childNodes)
                {
                    if (childNode.AddObject(ent, maxSublevels-1))
                    {
                        return true;
                    }
                }

                // if no child leaf returns true on AddObject add it to this.contents
                this.contents.Add(ent);
                return true;
            }

            // if it doesn't return false
            return false;
        }

        /// <summary> returns a list of objects contained in area
        /// </summary>
        public void FindObjects(BoundingBox area, ref List<GraphicsEntity> outObjects)
        {
            if (area.Contains(this.aabb) != ContainmentType.Disjoint)
            {
                outObjects.AddRange(this.contents);
                if (null != this.childNodes)
                {
                    foreach (BSPNode child in this.childNodes)
                    {
                        child.FindObjects(area, ref outObjects);
                    }
                }
            }
        }
}
}
