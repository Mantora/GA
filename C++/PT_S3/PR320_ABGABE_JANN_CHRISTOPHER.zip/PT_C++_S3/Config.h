#pragma once

/***************************************************************************
This is the configuration file 4 this projekt:

Take controll of the DEBUG behavior
or
modify core variables such as ADDITIONL_MINUTES_TO_BOARDING
***************************************************************************/

//DEBUG VARIABLES
#define DEBUG_STATIONS false
#define DEBUG_TIME false
#define DEBUG_XML false

//OTHER CONFIG VARIABLES
#define ADDITIONL_MINUTES_TO_BOARDING 5
#define MULTIPLAYER_IF_LINE_IS_OUT_OPERATION_TIME 5
